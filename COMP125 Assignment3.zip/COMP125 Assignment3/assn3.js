 // Function to increase image size 
  function enlargeImg(img) {
    img.style.transform = "scale(1.5)";
    img.style.transition =
      "transform 0.25s ease";
  } 

  window.onload = function() {

  document.getElementById('foo').addEventListener('click', function (e) {
    var img = document.createElement('img');
    img.setAttribute('src', 'http://blog.stackoverflow.com/wp-content/uploads/stackoverflow-logo-300.png');
    e.target.appendChild(img);
  });

};
function myFunction() {
  // Get the checkbox
  var checkBox = document.getElementById("myCheck1");
  // Get the output text
  var text = document.getElementById("text");
  var checkBox = document.getElementById("myCheck2");
  var image1 = document.getElementById("girl2");

  // If the checkbox is checked, display the output text
  if (checkBox.checked == true){text.style.display = "block";
  } else {text.style.display = "none";
  }
}
function picture1(){ 
        var pic = "http://i.huffpost.com/gen/749263/original.jpg"
        document.getElementById('bigpic1').src = pic.replace('10x10', '25x25');

        }

        function picture2(){ 
        var pic = "beautiful girl.png"
        document.getElementById('bigpic2').src = pic.replace('90x90', '225x225');

        }


        function picture3(){ 
        var pic = "Keep-Yourself-Hydrated.jpg.webp"
        document.getElementById('bigpic3').src = pic.replace('90x90', '225x225');

        }

        function picture4(){ 
        var pic = "lookalike.png"
        document.getElementById('bigpic4').src = pic.replace('90x90', '225x225');

        }


        function picture5(){ 
        var pic = "Marina.jpg"
        document.getElementById('bigpic5').src = pic.replace('90x90', '225x225');

        }






        //http://img.tesco.com/Groceries/pi/118/5000175411118/IDShot_90x90.jpg 